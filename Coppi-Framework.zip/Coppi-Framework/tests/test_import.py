def test_import():
    import sys
    sys.path.append("src")
    import coppi_framework
    assert hasattr(coppi_framework, "__version__")
