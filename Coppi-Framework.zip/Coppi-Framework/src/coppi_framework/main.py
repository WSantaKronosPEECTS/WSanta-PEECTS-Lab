"""Main entrypoint for Coppi Framework."""
def hello():
    """Return a friendly greeting."""
    return "Hello from Coppi Framework"
if __name__ == "__main__":
    print(hello())
