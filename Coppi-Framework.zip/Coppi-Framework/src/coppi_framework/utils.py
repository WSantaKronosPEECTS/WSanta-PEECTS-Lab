"""Utilities for Coppi Framework."""
def add(a: int, b: int) -> int:
    """Add two integers and return the result.

    Args:
        a: first integer
        b: second integer
    Returns:
        Sum of a and b.
    """
    return a + b
