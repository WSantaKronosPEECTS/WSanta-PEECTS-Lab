# Getting Started

Instale con `pip install -e .` y ejecute los ejemplos.
