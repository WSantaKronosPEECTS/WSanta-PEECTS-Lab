# Contributing

Por favor abra issues y pull requests.
