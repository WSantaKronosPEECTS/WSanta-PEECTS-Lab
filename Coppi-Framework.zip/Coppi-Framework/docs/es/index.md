# Coppi-Framework Documentation (es)

Framework repo for the Coppi/Kronas architecture.
