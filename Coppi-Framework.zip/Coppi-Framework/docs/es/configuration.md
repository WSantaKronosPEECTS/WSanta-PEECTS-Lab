# Configuration

Edite `config.json` para adaptar el comportamiento.
