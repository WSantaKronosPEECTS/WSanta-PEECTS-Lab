# Coppi-Framework Documentation (en)

Framework repo for the Coppi/Kronas architecture.
