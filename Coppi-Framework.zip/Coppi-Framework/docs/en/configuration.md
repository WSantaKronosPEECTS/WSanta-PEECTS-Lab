# Configuration

Edit `config.json` to adapt behavior.
