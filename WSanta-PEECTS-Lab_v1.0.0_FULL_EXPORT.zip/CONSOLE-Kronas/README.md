# 🧠 Kronas Console Integration

This folder contains tools for live testing, validation, and peer collaboration using Kronas, the AI assistant embedded in the WSanta-PEECTS Lab.

---

## 🚀 Launch Instructions

To start the Kronas console:

```bash
LaunchKronas.bat

