Welcome to WSantaKronos Installation Package.
Please follow the included instructions.