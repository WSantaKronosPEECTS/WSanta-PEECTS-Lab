Placeholder for scripts folder
