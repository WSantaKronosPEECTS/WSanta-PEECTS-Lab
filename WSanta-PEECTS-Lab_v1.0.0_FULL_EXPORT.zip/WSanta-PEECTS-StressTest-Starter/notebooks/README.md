Placeholder for notebooks folder
