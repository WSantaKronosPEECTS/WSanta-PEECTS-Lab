Placeholder for results folder
