# 🚀 Getting Started with the PEECTS Lab

Welcome to the WSanta-PEECTS-Lab repository. This guide will help you launch the VM appliance, validate public models, and contribute ethically.

## 🧪 Run the VM Appliance

1. **Clone the repository**
   ```bash
   git clone https://github.com/WSantaKronosPEECTS/WSanta-PEECTS-Lab.git
